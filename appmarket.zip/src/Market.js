import { StatusBar } from 'expo-status-bar';
import { ScrollView, StyleSheet, Image, Text, View } from 'react-native';

export default function App() {
    return (
        <ScrollView contentContainerStyle={styles.container}>
            <View style={styles.ViewLogo}>
                <View>
                    <Image style={styles.imageLogo} source={require('../assets/logoMercado.png')} />
                </View>
                <View style={styles.imageTituloBackGround}>
                    <Image style={styles.imageTitulo} source={require('../assets/titulo.png')} />
                </View>
            </View>
        </ScrollView>
    );
}
const styles = StyleSheet.create({
    container: {
        backgroundColor: '#428556'
    },
    imageLogo: {
        width: 200,
        height: 200,
    },
    imageTitulo: {
        width: 200,
        height: 100,

    },
    imageTituloBackGround: {
        paddingLeft: 100,
        paddingRight: 100,
    },
    ViewLogo: {
        alignItems: 'center',
        padding: 10,
    },
});